@echo off
title Pterodactyl native pterodactyl miner
echo Thanks for earning PteroCoins!
java -jar QuackhostMiner-1.21.jar --debug --cpulimit 70 --id 828787253215494154
pause
